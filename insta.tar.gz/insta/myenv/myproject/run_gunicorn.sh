gunicorn --bind 0:8000 myproject.wsgi:application
